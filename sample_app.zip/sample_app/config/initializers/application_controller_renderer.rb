# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'e8297720528ccfeeabca6bb05793252d0aee479e211cf067871587cbb2ec9e877c7410cb37464ce919e6e6f161405fdf86eece1424d0f7e3ec7d6e8df81f1780'